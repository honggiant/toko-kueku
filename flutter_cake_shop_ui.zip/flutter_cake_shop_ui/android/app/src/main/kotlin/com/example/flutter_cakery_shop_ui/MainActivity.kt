package com.example.flutter_cakery_shop_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
